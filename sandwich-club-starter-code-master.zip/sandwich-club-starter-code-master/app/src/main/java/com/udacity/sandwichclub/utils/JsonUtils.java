package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        JSONObject jsonObject;
        JSONObject jsonObjectName;
        String mainName = null;
        List<String> alsoKnownAs = new ArrayList<>();
        List<String> ingredients = new ArrayList<>();
        String placeOfOrigin = null;
        String description = null;
        String image = null;

        try {
            jsonObject = new JSONObject(json);
            jsonObjectName = jsonObject.getJSONObject("name");
            mainName = jsonObjectName.getString("mainName");
            placeOfOrigin = jsonObject.optString("placeOfOrigin");
            description = jsonObject.getString("description");
            image = jsonObject.getString("image");
            alsoKnownAs = JsonArrayListParse(jsonObjectName.getJSONArray("alsoKnownAs"));
            ingredients = JsonArrayListParse(jsonObject.getJSONArray("ingredients"));

        }catch (JSONException e){
            e.printStackTrace();
        }

        return new  Sandwich(mainName,alsoKnownAs,placeOfOrigin,description,image,ingredients);
    }

    private static List<String> JsonArrayListParse(JSONArray jsonArray)
    {
        List<String> newList = new ArrayList<>(0);
        if(jsonArray!=null)
        {
            for (int i = 0;i<jsonArray.length() ; i++)
            {
                try {
                    newList.add(jsonArray.getString(i));
                }catch (JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }
        return newList;
    }
}
